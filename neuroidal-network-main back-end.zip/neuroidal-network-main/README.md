# Neuroidal Network Application

## Running Flask

First, install Flask: `pip install flask`

Then, go into the web_app folder and run the commands below.

### Mac/Linux
`export FLASK_APP=main.py`

`flask run`

### Windows
`set FLASK_APP=main.py`

`flask run`
